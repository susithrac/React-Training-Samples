import React from 'react';

const Message = () => {
    return (
        <p>This is a quick message!!!</p>
    );
}

export default Message;
